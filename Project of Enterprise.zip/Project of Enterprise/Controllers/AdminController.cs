﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Project_of_Enterprise.Areas.Identity.Data;
using Project_of_Enterprise.Models; // Assuming your models are here
using System.Threading.Tasks;

namespace Project_of_Enterprise.Controllers

{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly ApplicationDBContext _context;

       
        public AdminController(ApplicationDBContext context)
        {
            _context = context; 
        }

        public ViewResult Home()
        {
            return View();
        }

    
        public async Task<IActionResult> ViewRoomDetails()
        {
            var rooms = await _context.Rooms.ToListAsync();
            return View(rooms); 
        }

        public IActionResult AddRoom()
        {
            return View(); 
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddRoom(RoomDetails room)
        {
            
                _context.Rooms.Add(room); 
                await _context.SaveChangesAsync(); 
                return RedirectToAction(nameof(ViewRoomDetails)); 
            

            return View(room); 
        }

        public IActionResult UpdateRoom(int id)
        {
            var room = _context.Rooms.Find(id); 
            if (room == null)
            {
                return NotFound(); 
            }

            return View(room); 
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateRoom(int id, RoomDetails room)
        {
            if (id != room.RoomId) 
            {
                return NotFound();
            }

            
                _context.Update(room); 
                await _context.SaveChangesAsync(); 
                return RedirectToAction(nameof(ViewRoomDetails)); 
      

            return View(room); 
        }

        public async Task<IActionResult> DeleteRoom(int id)
        {
            var room = await _context.Rooms.FindAsync(id);
            if (room == null)
            {
                return NotFound();
            }

            _context.Rooms.Remove(room);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(ViewRoomDetails));
        }

    }
}
