﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Project_of_Enterprise.Controllers
{
    public class Front_PageController : Controller
    {

        public ViewResult Index()
        {
            return View();
        }

        public ViewResult AboutUs()
        {
            return View();
        }
      

        public ViewResult SingleRoom()
        {
            return View();
        }

        public ViewResult DoubleRoom()
        {
            return View();
        }

        public ViewResult SuiteRoom()
        {
            return View();
        }
        [Authorize(Policy = "CanBookRoomPolicy")]
        public ViewResult BookNow()
        {
            return View();
        }

        [Authorize(Policy = "CanBookRoomPolicy")]
        public ViewResult CancelledBooking()
        {
            return View();
        }
    }
}
