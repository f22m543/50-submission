﻿using System.ComponentModel.DataAnnotations;

namespace Project_of_Enterprise.Models
{
    public class RoomDetails
    {

        [Key]
        public int RoomId { get; set; }
        public string RoomNumber { get; set; }
        public string RoomType { get; set; }
        public string Status { get; set; }
        }

    public class BookingDetails
    {
            [Key]
            public int BookingId { get; set; }
            public string UserName { get; set; }
            public string RoomNumber { get; set; }
        }
}
